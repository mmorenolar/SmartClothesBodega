package smartclothesbodega;

public class Pantalon extends Producto implements Vendible {
    private String tipoCorte;
    private double precioBase;

    public Pantalon(String sku, String nombre, String foto, int stock, int precio, String talla, String color, String tipoCorte, double precioBase) {
        super(sku, nombre, foto, stock, talla, color);
        this.tipoCorte = tipoCorte;
        this.precioBase = precioBase;
    }

    public String getTipoCorte() {
        return this.tipoCorte;
    }

    // IMPLEMENTACIÓN DE LA INTERFAZ VENDIBLE 
    @Override
    public double getPrecioBase() {
        return this.precioBase;
    }

    @Override
    public double calcularPrecioFinal(double porcentajeDescuento) {
        return this.precioBase - (this.precioBase * (porcentajeDescuento / 100.0));
    }

    // IMPLEMENTACIÓN DEL MÉTODO ABSTRACTO 
    @Override
    public String obtenerDetalleCompleto() {
        return "PANTALÓN - SKU: " + getSku() + " | Nombre: " + getNombre() + 
               " | Corte: " + this.tipoCorte + " | Precio: $" + this.precioBase + 
               " | Stock: " + getStock() + " | Estado: " + getEstado();
    }
}