package smartclothesbodega;

// 1. Tipado: Java utiliza tipado ESTÁTICO y FUERTE (se declara el tipo de variable 
//    en compilación), a diferencia de lenguajes dinámicos como Python o JS.
// 2. Ciclo de Ejecución: Java compila el código fuente (.java) a Bytecode (.class) 
//    y luego la JVM lo ejecuta, combinando compilación e interpretación.
//
// Ventaja del Tipado Estático:
// El tipado estático permite al compilador detectar errores de tipo e incompatibilidad 
// de datos de manera TEMPRANA durante la COMPILACIÓN, evitando que el programa falle 
// en tiempo de ejecución.
// ============================================================================

public abstract class Producto {
    private String sku;
    private String nombre;
    private String foto;
    private int stock;
    private String talla;
    private String color;
    private String estado; 
    private int precio;
    
    public Producto(String sku, String nombre, String foto, int stock, String talla, String color, int precio){
        this.sku = sku;
        this.nombre = nombre;
        this.foto = foto;
        this.stock = stock;
        this.talla = talla;
        this.color = color;
        actualizarEstado();
    }

    private void actualizarEstado() {
        if (this.stock > 0) {
            this.estado = "Disponible";
        } else {
            this.estado = "Agotado";
        }
    }

    // MÉTODO BASE
    public boolean descontarStock(int cantidad) {
        if (cantidad <= this.stock) {
            this.stock = this.stock - cantidad;
            actualizarEstado();
            return true;
        }
        return false;
    } 

    // SOBRECARGA DE MÉTODOS: Segunda variante con distinta firma
    public boolean descontarStock(int cantidad, String motivo) {
        System.out.println("Ajuste de stock realizado por motivo: " + motivo);
        return descontarStock(cantidad); // Reutiliza el método base
    }

    // MÉTODO ABSTRACTO 
    public abstract String obtenerDetalleCompleto();

    public String getSku() { return this.sku; }
    public String getNombre() { return this.nombre; }
    public String getFoto() { return this.foto; }
    public int getStock() { return this.stock; }
    public String getTalla() { return this.talla; }
    public String getColor() { return this.color; }
    public String getEstado() { return this.estado; }
}