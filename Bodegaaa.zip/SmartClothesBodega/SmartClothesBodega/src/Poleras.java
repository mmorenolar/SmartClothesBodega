package smartclothesbodega;

public class Polera extends Producto implements Vendible {
    private String material;
    private double precio;

    public Polera(String sku, String nombre, String foto, int stock, String talla, String color, String material, double precio) {
        super(sku, nombre, foto, stock, talla, color);
        this.material = material;
        this.precio = precio;
    }

    public String getMaterial() {
        return this.material;
    }

    // IMPLEMENTACIÓN DE LA INTERFAZ VENDIBLE 
    @Override
    public double getPrecioBase() {
        return this.precio;
    }

    @Override
    public double calcularPrecioFinal(double porcentajeDescuento) {
        return this.precio - (this.precio * (porcentajeDescuento / 100.0));
    }

    // IMPLEMENTACIÓN DEL MÉTODO ABSTRACTO DE PRODUCTO 
    @Override
    public String obtenerDetalleCompleto() {
        return "POLERA - SKU: " + getSku() + " | Nombre: " + getNombre() + 
               " | Material: " + this.material + " | Precio: $" + this.precio + 
               " | Stock: " + getStock() + " | Estado: " + getEstado();
    }
}