package smartclothesbodega;

// La palabra clave 'extends' indica HERENCIA. 'Pantalon' es una SUBCLASE (clase hija) 
// que hereda la estructura, atributos y métodos de la SUPERCLASE 'Producto'.
public class Pantalon extends Producto {

    // 'private' aplica ENCAPSULAMIENTO. 
    // Utiliza el ENUM 'TipoCorte' para restringir los valores posibles del tipo de corte.
    private TipoCorte tipoCorte;

    // El CONSTRUCTOR inicializa los objetos tipo Pantalon.
    public Pantalon(String sku, String nombre, String foto, int stock, String talla, String color, TipoCorte tipoCorte) {
        // 'super(...)' llama al constructor de la superclase (Producto) para reutilizar 
        // la inicialización de los atributos heredados.
        super(sku, nombre, foto, stock, talla, color);
        this.tipoCorte = tipoCorte; // Asigna la constante del enum al atributo propio
    }

    // Métodos para consultar y modificar el valor del atributo privado.
    public TipoCorte getTipoCorte() {
        return this.tipoCorte;
    }

    public void setTipoCorte(TipoCorte tipoCorte) {
        this.tipoCorte = tipoCorte;
    }

    // Aplica POLIMORFISMO al sobrescribir el método abstracto definido en 'Producto',
    // ofreciendo una representación textual específica para los pantalones.
    @Override
    public String obtenerDetalleCompleto() {
        return "PANTALON | SKU: " + getSku() + 
               " | Nombre: " + getNombre() + 
               " | Corte: " + this.tipoCorte + 
               " | Talla: " + getTalla() + 
               " | Color: " + getColor() + 
               " | Stock: " + getStock() + 
               " | Estado: " + getEstado();
    }
}