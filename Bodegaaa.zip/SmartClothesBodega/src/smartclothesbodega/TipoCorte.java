package smartclothesbodega;

// Un ENUM es una estructura especial que define una lista restringida de CONSTANTES inmutables.
// Sirve para acotar las opciones de corte de pantalón a valores prefijados, evitando fallos
// por errores tipográficos al instanciar u operar con objetos de tipo 'Pantalon'.
public enum TipoCorte {
    Slim, 
    Regular, 
    Skinny
}