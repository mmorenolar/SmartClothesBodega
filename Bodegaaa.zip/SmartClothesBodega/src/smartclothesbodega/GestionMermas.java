package smartclothesbodega;

import java.util.ArrayList;
import java.util.List;

// Esta CLASE actúa como un controlador de negocio que administra la lógica de pérdidas o mermas.
// Es una plantilla que encapsula las operaciones relacionadas con dar de baja productos.
public class GestionMermas {

    // ATRIBUTO privado (Encapsulamiento) que almacena una lista dinámica de objetos tipo 'RegistroMerma'.
    // Protege el historial de modificaciones directas sin autorización externa.
    private List<RegistroMerma> historialMermas;

    // El CONSTRUCTOR inicializa la lista interna 'historialMermas' al instanciar el objeto.
    public GestionMermas() {
        this.historialMermas = new ArrayList<>();
    }
    // MÉTODO que recibe un objeto 'Producto' por parámetro.
    // Aplica POLIMORFISMO porque el parámetro 'Producto' puede ser cualquier subclase
    // (Pantalon, Polera o Calzado), y el método interactuará con cualquiera de ellos de forma transparente.
    public RegistroMerma registrarBaja(Producto producto, int cantidad, String observacion) throws IllegalArgumentException {
        
        // Validaciones de negocio antes de procesar el objeto
        if (producto == null) {
            throw new IllegalArgumentException("Error: El producto especificado no existe.");
        }
        if (cantidad <= 0) {
            throw new IllegalArgumentException("Error: La cantidad afectada debe ser mayor a 0.");
        }
        
        // Accedemos al stock mediante 'producto.getStock()' respetando el encapsulamiento del objeto recibido.
        if (cantidad > producto.getStock()) {
            throw new IllegalArgumentException("Error: La cantidad a dar de baja (" + cantidad + ") supera el stock disponible (" + producto.getStock() + ").");
        }
        
        // Invoca el método 'descontarStock' definido en la superclase/interfaz del producto.
        boolean exito = producto.descontarStock(cantidad, "Merma: " + observacion);

        if (exito) {
            // Crea un nuevo OBJETO de la clase 'RegistroMerma' para dejar constancia histórica.
            RegistroMerma merma = new RegistroMerma(producto.getSku(), cantidad, observacion);
            
            // Agrega el nuevo objeto a la lista de historial
            historialMermas.add(merma);
            
            return merma; // Retorna la instancia creada
        } else {
            throw new IllegalStateException("Error al procesar el descuento en el stock.");
        }
    }

    // Retorna una copia de la lista para mantener la seguridad del ENCAPSULAMIENTO
    // y evitar que la lista original sea alterada fuera de esta clase.
    public List<RegistroMerma> getHistorialMermas() {
        return new ArrayList<>(historialMermas);
    }
}