package smartclothesbodega;

import java.time.LocalDateTime;

// Esta CLASE representa la entidad de registro individual de pérdida o merma de un producto.
public class RegistroMerma {

    // 'static' define una variable compartida por todas las instancias de esta clase,
    // utilizada aquí como un autoincremental de identificadores (ID).
    private static int contadorId = 1;

    // Todos los atributos son definidos como 'private' para garantizar el ENCAPSULAMIENTO
    // y proteger el historial contra alteraciones indebidas.
    private int idMerma;
    private String skuProducto;
    private int cantidadAfectada;
    private String observacionJustificativa;
    private String fechaHora;

    // El CONSTRUCTOR inicializa los valores del registro asignando un ID único global 
    // y capturando el momento exacto en que ocurre la baja de stock.
    public RegistroMerma(String skuProducto, int cantidadAfectada, String observacionJustificativa) {
        this.idMerma = contadorId++; // Asigna el valor actual de contadorId y luego lo incrementa
        this.skuProducto = skuProducto;
        this.cantidadAfectada = cantidadAfectada;
        this.observacionJustificativa = observacionJustificativa;
        this.fechaHora = LocalDateTime.now().toString();
    }

    // Entregan un acceso de solo lectura (sin setters) para preservar la integridad del registro.
    public int getIdMerma() { return idMerma; }
    public String getSkuProducto() { return skuProducto; }
    public int getCantidadAfectada() { return cantidadAfectada; }
    public String getObservacionJustificativa() { return observacionJustificativa; }
    public String getFechaHora() { return fechaHora; }

    // MÉTODO público que concatena el estado interno del objeto para emitir un comprobante.
    public String obtenerComprobante() {
        return "====================================================================\n" +
               "          REGISTRO DE MERMA N " + idMerma + "\n" +
               "====================================================================\n" +
               "Fecha/Hora: " + fechaHora + "\n" +
               "SKU Producto: " + skuProducto + "\n" +
               "Cantidad Afectada: " + cantidadAfectada + "\n" +
               "Observacion: " + observacionJustificativa + "\n" +
               "---------------------------------------------------------------------";
    }
}