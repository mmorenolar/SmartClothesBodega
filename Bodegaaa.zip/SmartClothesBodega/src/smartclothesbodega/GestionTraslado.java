package smartclothesbodega;

// Esta CLASE actúa como un controlador del sistema encargado de coordinar la lógica
// de negocio correspondiente al despacho y traslado de prendas hacia tiendas externas.
public class GestionTraslado {

    // MÉTODO que recibe arreglos de 'Producto' y 'cantidades'.
    // Aplica POLIMORFISMO porque el arreglo 'Producto[]' maneja de forma transparente 
    // distintas instancias de subclases (Pantalon, Polera o Calzado).
    public OrdenTraslado crearOrden(String tiendaDestino, Producto[] productos, int[] cantidades) {
        
        // Validación de consistencia en los datos recibidos
        if (productos.length != cantidades.length) {
            System.out.println("ERROR: La lista de productos y cantidades no coinciden.");
            return null;
        }

        // 1. Validar estado y stock disponible antes de autorizar el envío
        for (int i = 0; i < productos.length; i++) {
            // La variable 'p' almacena dinámicamente un objeto concreto derivado de Producto.
            Producto p = productos[i];
            int cantidadPedida = cantidades[i];

            if (p == null) {
                System.out.println("ERROR: Uno de los productos seleccionados no existe.");
                return null;
            }

            // Se le solicita la información al objeto respetando el encapsulamiento de sus atributos.
            if (!p.getEstado().equals("Disponible")) {
                System.out.println("ERROR: El producto " + p.getSku() + " está Agotado.");
                return null;
            }
            if (cantidadPedida > p.getStock()) {
                System.out.println("ERROR: Stock insuficiente para " + p.getSku() + ". Disponible: " + p.getStock());
                return null;
            }
        }

        // 2. Si pasa las validaciones, descuenta stock e ingresa la orden
        // Se crea un nuevo OBJETO 'orden' de la clase 'OrdenTraslado' para consolidar la transacción.
        OrdenTraslado orden = new OrdenTraslado(tiendaDestino, productos.length);
        
        for (int i = 0; i < productos.length; i++) {
            // Llama al método 'descontarStock' que modifica el atributo privado dentro del producto de manera segura.
            productos[i].descontarStock(cantidades[i]);
            
            // Registra el detalle del traslado dentro de la orden creada
            orden.agregarDetalle(productos[i], cantidades[i]);
        }

        return orden; // Retorna la instancia de la orden generada
    }
}