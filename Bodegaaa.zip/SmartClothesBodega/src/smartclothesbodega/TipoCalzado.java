package smartclothesbodega;

// Un ENUM es un tipo especial de clase que define un grupo fijo e inmutable de CONSTANTES.
// Garantiza la integridad de los datos en la aplicación al evitar errores de escritura 
// y restringir las opciones de estilo de calzado a únicamente los valores declarados aquí.
public enum TipoCalzado {
    DEPORTIVO,
    CASUAL,
    FORMAL,
    URBANO
}