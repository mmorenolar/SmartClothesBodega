package smartclothesbodega;

import java.time.LocalDate;

// Esta CLASE encapsula la información de un documento o transacción de despacho.
public class OrdenTraslado {

    // 'static' significa que este atributo pertenece a la clase y no a un objeto individual.
    // Se utiliza como un contador global compartido para autogenerar folios únicos.
    private static int contadorFolio = 1001;

    // 'private' aplica ENCAPSULAMIENTO para proteger la información del documento de traslados.
    private int folio;
    private String fechaDespacho;
    private String tiendaDestino;

    // Arreglo que almacena múltiples OBJETOS de la clase 'DetalleTraslado'.
    private DetalleTraslado[] detalles;
    private int cantidadDetalles;

    // Inicializa el objeto asignando un folio único dinámico e instanciando el arreglo interno.
    public OrdenTraslado(String tiendaDestino, int capacidadMaxima) {
        this.folio = contadorFolio++; // Asigna el contador actual e incrementa para el próximo objeto
        this.fechaDespacho = LocalDate.now().toString();
        this.tiendaDestino = tiendaDestino;
        this.detalles = new DetalleTraslado[capacidadMaxima];
        this.cantidadDetalles = 0;
    }

    // MÉTODO que recibe un 'Producto' y una 'cantidad' para crear e insertar un nuevo objeto 'DetalleTraslado'.
    public void agregarDetalle(Producto producto, int cantidad) {
        if (cantidadDetalles < detalles.length) {
            // Instanciación de un nuevo objeto DetalleTraslado dentro del arreglo
            detalles[cantidadDetalles] = new DetalleTraslado(producto, cantidad);
            cantidadDetalles++;
        }
    }

    // Genera la representación en formato de texto del comprobante leyendo los datos encapsulados.
    public String emitirComprobante() {
        String comprobante = "==================================================================\n" +
                             "          COMPROBANTE ORDEN DE TRASLADO N " + folio + "\n" +
                             "==================================================================\n" +
                             "Fecha Despacho : " + fechaDespacho + "\n" +
                             "Tienda Destino : " + tiendaDestino + "\n" +
                             "------------------------------------------------------------------\n" +
                             "PRODUCTOS TRANSFERIDOS:\n";

        for (int i = 0; i < cantidadDetalles; i++) {

            // Obtiene el objeto Producto almacenado en la posición 'i'
            Producto p = detalles[i].getProducto();
            int cant = detalles[i].getCantidad();
            
            // Accede a los métodos Getters de Producto respetando el encapsulamiento
            comprobante += " - SKU: " + p.getSku() + 
                           " | " + p.getNombre() + 
                           " | Talla: " + p.getTalla() + 
                           " | Color: " + p.getColor() + 
                           " | Cantidad: " + cant + "\n";
        }
        comprobante += "-------------------------------------------------------------------------";
        return comprobante;
    }

    // Proporciona acceso de solo lectura al número de folio del documento.
    public int getFolio() { return folio; }
}