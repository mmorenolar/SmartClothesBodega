package smartclothesbodega;

// La palabra clave 'extends' indica HERENCIA. 'Calzado' es una SUBCLASE (clase hija) 
// que hereda todos los atributos, métodos y el contrato de la SUPERCLASE 'Producto'.
public class Calzado extends Producto {

    // 'private' aplica ENCAPSULAMIENTO para proteger este dato.
    // Utiliza el ENUM 'TipoCalzado' como tipo de dato estricto, restringiendo los valores válidos a una lista fija.
    private TipoCalzado tipoCalzado;

    // El CONSTRUCTOR inicializa los objetos tipo Calzado.
    public Calzado(String sku, String nombre, String foto, int stock, String talla, String color, TipoCalzado tipoCalzado) {
        // 'super(...)' invoca al constructor de la superclase (Producto) para reutilizar 
        // la lógica de inicialización de los atributos heredados.
        super(sku, nombre, foto, stock, talla, color);
        this.tipoCalzado = tipoCalzado; // Asigna el valor del atributo propio de esta subclase
    }

    // 'get' permite consultar el estado del atributo protegido.
    public TipoCalzado getTipoCalzado() {
        return this.tipoCalzado;
    }

    // 'set' permite modificar de forma controlada el valor del atributo privado.
    public void setTipoCalzado(TipoCalzado tipoCalzado) {
        this.tipoCalzado = tipoCalzado;
    }

    // La anotación '@Override' indica que estamos aplicando POLIMORFISMO. 
    // Sobrescribimos el método abstracto heredado de 'Producto' para darle un comportamiento específico de Calzado.
    @Override
    public String obtenerDetalleCompleto() {
        // Usa los métodos 'get' heredados para acceder a los datos privados de la superclase Producto
        return "CALZADO | SKU: " + getSku() +
               " | Nombre: " + getNombre() +
               " | Estilo: " + this.tipoCalzado +
               " | Talla: " + getTalla() +
               " | Color: " + getColor() +
               " | Stock: " + getStock() +
               " | Estado: " + getEstado();
    }
}