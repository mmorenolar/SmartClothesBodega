package smartclothesbodega;

// 'abstract class' define una CLASE ABSTRACTA que sirve como plantilla general de la que heredan otras.
// No se puede instanciar directamente, solo extender.
// 'implements IGestionable' asume un contrato formal, obligando a implementar los métodos de la interfaz.
public abstract class Producto implements IGestionable {

    // Modificador 'private' para aplicar ENCAPSULAMIENTO. 
    // Protege el estado del objeto para que solo se acceda a través de sus métodos autorizados.
    private String sku;
    private String nombre;
    private String foto;
    private int stock;
    private String talla;
    private String color;
    private String estado; 

    // El CONSTRUCTOR inicializa los atributos obligatorios al instanciar una subclase de Producto.
    public Producto(String sku, String nombre, String foto, int stock, String talla, String color) {
        this.sku = sku;
        this.nombre = nombre;
        this.foto = foto;
        this.stock = stock;
        this.talla = talla;
        this.color = color;
        actualizarEstado(); // Garantiza la consistencia inicial del objeto
    }

    // MÉTODO auxiliar de acceso privado que ajusta automáticamente la variable 'estado'
    // protegiendo la regla de negocio internamente.
    private void actualizarEstado() {
        if (this.stock > 0) {
            this.estado = "Disponible";
        } else {
            this.estado = "Agotado";
        }
    }

    // Implementación del método heredado de la interfaz. Modifica de forma segura la variable 'stock'.
    @Override
    public boolean descontarStock(int cantidad) {
        if (cantidad > 0 && cantidad <= this.stock) {
            this.stock -= cantidad;
            actualizarEstado(); // Recalcula el estado interno respetando el encapsulamiento
            return true;
        }
        return false;
    } 

    // Reutiliza la firma del método 'descontarStock' para recibir un parámetro adicional ('motivo').
    @Override
    public boolean descontarStock(int cantidad, String motivo) {
        return descontarStock(cantidad);
    }

    // Un MÉTODO ABSTRACTO no tiene cuerpo; exige que cada clase hija (Pantalon, Polera, Calzado)
    // entregue su propia versión concreta (Polimorfismo).
    @Override
    public abstract String obtenerDetalleCompleto();

    // Genera el reporte final estructurado exigido por la interfaz IGestionable.
    @Override
    public String obtenerReporteFinal() {
        String alerta = (this.stock == 0) ? "[CRITICO: SIN STOCK]" : 
                       (this.stock < 5)  ? "[ALERTA: REAPROVISIONAR]" : "[OK]";

        return String.format(
            "+--------------------------------------------------------+\n" +
            "| PRODUCTO: %-25s SKU: %-12s |\n" +
            "| Talla: %-5s | Color: %-10s | Estado: %-10s |\n" +
            "| Unidades Disponibles: %-3d %-25s |\n" +
            "+--------------------------------------------------------+",
            this.nombre, this.sku, this.talla, this.color, this.estado, this.stock, alerta
        );
    }

    // Permiten consultar las variables privadas desde el exterior sin alterar su valor directamente.
    public String getSku() { return sku; }
    public String getNombre() { return nombre; }
    public String getFoto() { return foto; }
    public int getStock() { return stock; }
    public String getTalla() { return talla; }
    public String getColor() { return color; }
    public String getEstado() { return estado; }
}