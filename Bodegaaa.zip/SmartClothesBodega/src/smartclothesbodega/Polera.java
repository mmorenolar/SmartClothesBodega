package smartclothesbodega;

// La palabra clave 'extends' establece la relación de HERENCIA.
// 'Polera' es una SUBCLASE (clase hija) que hereda todos los atributos y métodos de 'Producto'.
public class Polera extends Producto {

    // Modificador 'private' para aplicar ENCAPSULAMIENTO.
    // Utiliza el ENUM 'TipoPolera' como tipo de dato para restringir las opciones del tipo de cuello/corte.
    private TipoPolera tipoPolera;

    // El CONSTRUCTOR inicializa los objetos tipo Polera.
    public Polera(String sku, String nombre, String foto, int stock, String talla, String color, TipoPolera tipoPolera) {
        // 'super(...)' invoca al constructor de la superclase (Producto) para reutilizar 
        // la inicialización de los atributos comunes.
        super(sku, nombre, foto, stock, talla, color);
        this.tipoPolera = tipoPolera; // Asigna el tipo de polera propio de esta clase
    }

    // Métodos de acceso y modificación para el atributo privado.
    public TipoPolera getTipoPolera() {
        return this.tipoPolera;
    }

    public void setTipoPolera(TipoPolera tipoPolera) {
        this.tipoPolera = tipoPolera;
    }

    // La anotación '@Override' indica POLIMORFISMO.
    // Sobrescribe el método abstracto de 'Producto' para formatear el detalle específico de la polera.
    @Override
    public String obtenerDetalleCompleto() {
        return "POLERA | SKU: " + getSku() +
               " | Nombre: " + getNombre() +
               " | Tipo: " + this.tipoPolera +
               " | Talla: " + getTalla() +
               " | Color: " + getColor() +
               " | Stock: " + getStock() +
               " | Estado: " + getEstado();
    }
}