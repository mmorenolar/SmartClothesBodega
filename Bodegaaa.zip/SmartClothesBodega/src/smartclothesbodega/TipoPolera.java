package smartclothesbodega;

// Un ENUM representa un conjunto inmutable de CONSTANTES nombradas.
// Permite restringir el atributo de tipo de cuello o diseño en los objetos 'Polera',
// asegurando la consistencia de los datos en toda la gestión de bodega.
public enum TipoPolera {
    CUELLO_V,
    CUELLO_REDONDO,
    POLO,
    SIN_MANGAS
}