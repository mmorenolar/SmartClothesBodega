package smartclothesbodega;

// Esta CLASE contiene el punto de entrada al programa ('main'). 
// Coordina el ciclo de vida de los objetos, las llamadas a los controladores y las salidas por consola.
public class SmartClothesBodega {

    // MÉTODO 'main' público y estático que ejecuta la aplicación.
    public static void main(String[] args) {
        System.out.println("=== SISTEMA SMART CLOTHES - BODEGA PRINCIPAL ===");

        // Se crean los OBJETOS gestores que procesarán la lógica de negocio del sistema.
        GestionMermas gestorMermas = new GestionMermas();
        GestionTraslado gestorTraslados = new GestionTraslado();

        // Se crean las INSTANCIAS (objetos concretos) de prendas pasando constantes ENUM como argumentos.
        Pantalon pantalon1 = new Pantalon("PANT-001", "Pantalon Mezclilla", "pantalon.jpg", 10, "42", "Azul", TipoCorte.Slim);
        Polera polera1 = new Polera("POL-002", "Polera Basica", "polera.jpg", 5, "M", "Blanca", TipoPolera.CUELLO_REDONDO);
        Calzado calzado1 = new Calzado("ZAP-003", "Zapatillas Urbanas", "zap.jpg", 8, "41", "Negro", TipoCalzado.CASUAL);

        System.out.println("\n--- INVENTARIO INICIAL BODEGA ---");

        // Cada tipo de prenda responde a 'obtenerDetalleCompleto()' entregando su formato particular.
        System.out.println(pantalon1.obtenerDetalleCompleto());
        System.out.println(polera1.obtenerDetalleCompleto());
        System.out.println(calzado1.obtenerDetalleCompleto());

        // PROCESO 1: Mermas y Pérdidas
        System.out.println("\n--- APLICANDO GESTION DE MERMAS ---");

        // El método 'registrarBaja' acepta el objeto 'polera1' porque hereda de la superclase 'Producto'.
        RegistroMerma m1 = gestorMermas.registrarBaja(polera1, 5, "Humedad en bodega principal");
        if (m1 != null) {
            System.out.println(m1.obtenerComprobante());
        }

        // PROCESO 2: Orden de Traslado a Tienda
        System.out.println("\n--- GENERANDO ORDEN DE TRASLADO ---");

        // Un arreglo de tipo 'Producto[]' almacena referencias a instancias de subclases heterogéneas.
        Producto[] productosEnvio = {pantalon1, calzado1};
        int[] cantidadesEnvio = {4, 3};

        OrdenTraslado orden = gestorTraslados.crearOrden("Tienda Centro Plaza", productosEnvio, cantidadesEnvio);
        if (orden != null) {
            System.out.println(orden.emitirComprobante());
        }

        System.out.println("\n--- INVENTARIO FINAL EN BODEGA (REPORTE DETALLADO) ---");

        // Invoca el método 'obtenerReporteFinal()' exigido por la interfaz 'IGestionable'.
        System.out.println(pantalon1.obtenerReporteFinal());
        System.out.println(polera1.obtenerReporteFinal());
        System.out.println(calzado1.obtenerReporteFinal());
    }
}