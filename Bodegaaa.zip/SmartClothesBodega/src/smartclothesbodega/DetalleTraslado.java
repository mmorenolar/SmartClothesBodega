package smartclothesbodega;

// Esta CLASE representa una entidad que encapsula la relación entre un producto y la cantidad a trasladar.
public class DetalleTraslado {

    // 'private' aplica ENCAPSULAMIENTO para proteger la información del detalle.
    // El atributo 'producto' utiliza POLIMORFISMO: puede contener cualquier objeto que sea subclase de 'Producto'
    // (un Pantalon, una Polera o un Calzado).
    private Producto producto;
    private int cantidad;

    // El CONSTRUCTOR inicializa los datos obligatorios al instanciar este objeto.
    public DetalleTraslado(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
    }

    // Permiten consultar los atributos privados desde fuera de la clase sin permitir su modificación directa.
    public Producto getProducto() { 
        return producto; 
    }

    public int getCantidad() { 
        return cantidad; 
    }
}