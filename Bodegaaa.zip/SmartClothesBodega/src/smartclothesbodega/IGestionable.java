package smartclothesbodega;

// Una INTERFAZ es un contrato formal que establece un conjunto de métodos obligatorios.
// Define QUÉ acciones debe poder realizar cualquier clase de la bodega, sin imponer CÓMO deben ejecutarse.
public interface IGestionable {

    // Firma obligatoria para devolver la vista resumida de la prenda.
    String obtenerDetalleCompleto();

    // Firma obligatoria para generar la presentación detallada al cierre del inventario.
    String obtenerReporteFinal();

    // Aplicación de POLIMORFISMO mediante Sobrecarga.
    // Obliga a las clases a implementar dos variantes para el descuento de stock.
    boolean descontarStock(int cantidad);

    boolean descontarStock(int cantidad, String motivo);
}